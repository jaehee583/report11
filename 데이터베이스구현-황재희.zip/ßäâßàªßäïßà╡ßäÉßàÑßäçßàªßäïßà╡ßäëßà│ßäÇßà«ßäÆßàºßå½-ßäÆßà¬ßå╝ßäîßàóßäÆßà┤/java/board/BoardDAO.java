package board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.DriverManager;
//import java.util.ArrayList;

public class BoardDAO {
	
	private Connection conn;
	private ResultSet rs;
	private PreparedStatement pstmt;
	
	public BoardDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS_db";
			String dbID = "root";
			String dbPassword = "root";
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection(dbURL,dbID,dbPassword);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Board> getBoard() {
		String SQL = "SELECT * FROM board ORDER BY boardNum";
		ArrayList<Board> list = new ArrayList<Board>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Board board=new Board();
				board.setBoardNum(rs.getInt(1));
				board.setBoardTitle(rs.getString(2));
				board.setBoardContent(rs.getString(3));
				list.add(board);
			}
		}catch (Exception e) {
			e.printStackTrace();			
		}
		return list;
		
	}
	
	public Board getBoard(int boardNum) {
		String SQL = "SELECT * FROM board WHERE boardNum=? ORDER BY boardNum DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, boardNum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				Board board=new Board();
				board.setBoardNum(rs.getInt(1));
				board.setBoardTitle(rs.getString(2));
				board.setBoardContent(rs.getString(3));				
				return board;
			}
		}catch (Exception e) {
			e.printStackTrace();			
		}		
		
		return null;
	}
	
	public int nextBoardNum() {
		String SQL = "SELECT boardNum FROM board ORDER BY boardNum DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;	
			}else {
				return 1;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	return -1;
	}
	
	public int boardWrite(String boardTitle,String boardContent) {
		String SQL = "INSERT INTO board VALUES(?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, nextBoardNum());
			pstmt.setString(2, boardTitle);
			pstmt.setString(3, boardContent);
			return pstmt.executeUpdate();			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
}
